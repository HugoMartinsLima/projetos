package loyalty.com.br.loyalty.presenter;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import loyalty.com.br.loyalty.MainActivity;
import loyalty.com.br.loyalty.model.bean.UserCashier;
import loyalty.com.br.loyalty.model.bean.UserClient;
import loyalty.com.br.loyalty.task.UserTask;

/**
 * Created by root on 09/10/15.
 */
public class LoginPresenterImpl implements LoginPresenter {

    private Activity activity;
    private EditText mNameView;
    private EditText mPasswordView;
    private UserClient userClient;
    Button mEmailSignInButton;
    final UserCashier userCashier = new UserCashier();

    public LoginPresenterImpl(Activity activity) {
        this.activity = activity;
    }

    public void init() {
        mNameView = (EditText) activity.findViewById(R.id.edt_name);
        mPasswordView = (EditText) activity.findViewById(R.id.edt_password);
        Button mEmailSignInButton = (Button) activity.findViewById(R.id.sign);
        mEmailSignInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userCashier.setName(mNameView.getText().toString());
                userCashier.setPassword(mPasswordView.getText().toString());
                UserTask userTask = new UserTask(activity, userCashier);
                userTask.execute();
            }
        });
    }

    @Override
    public void validateCredentials(UserCashier userCashier) {
        Intent intent = new Intent();
        if (userCashier != null) {
            intent.putExtra("userCashier", userCashier);
            intent.putExtra("actionFragment", "doispos");
            intent.setClass(activity, MainActivity.class);
        } else if (userCashier == null) {
            intent.setClass(activity, Login.class);
        }
        activity.startActivity(intent);
    }
}
