package loyalty.com.br.loyalty.presenter;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;

import br.com.loyalty.loyalty.R;
import br.com.loyalty.loyalty.model.bean.UserCashier;

/**
 * Created by hugo on 14/12/15.
 */
public class UserCashierPresenter {

    private Button button1;
    private ImageView espacoFoto;
    private String localArquivoFoto;
    private UserCashier userCashier = new UserCashier();
    private Activity activity;

    public UserCashierPresenter(Activity activity, UserCashier userCashier) {
        activity = activity;
        userCashier = userCashier;
    }


    public void init() {


    }


}
