package loyalty.com.br.loyalty.model.bean;

import android.content.Intent;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.net.UnknownServiceException;

/**
 * Created by root on 07/10/15.
 */

@DatabaseTable
public class UserCashier implements IEntiyBean {

    @DatabaseField(generatedId = true)
    private Long id;
    @DatabaseField
    private String name;
    @DatabaseField
    private String email;
    @DatabaseField
    private String password;
    private Company company;
    private Float cashback;
    private Float resgate;
    private Integer comprasCanceladas;
    private String photo;

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserCashier userCashier = (UserCashier) o;

        return !(id != null ? !id.equals(userCashier.id) : userCashier.id != null);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Float getCashBack() {
        return cashback;
    }

    public void setCashBack(Float cashBack) {
        this.cashback = cashBack;
    }

    public Float getResgate() {
        return resgate;
    }

    public void setResgate(Float resgate) {
        this.resgate = resgate;
    }

    public Integer getComprasCanceladas() {
        return comprasCanceladas;
    }

    public void setComprasCanceladas(Integer comprasCanceladas) {
        this.comprasCanceladas = comprasCanceladas;
    }

    public Float getCashback() {
        return cashback;
    }

    public void setCashback(Float cashback) {
        this.cashback = cashback;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
