package loyalty.com.br.loyalty_final_master.Task;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

import java.net.URL;

/**
 * Created by hugo on 2/2/16.
 */
public class ImageTask extends AsyncTask<Object, Object, Bitmap> {
    private ProgressDialog progress;
    private Activity context;
    private ImageView image;

    public ImageTask(Activity context, ImageView image) {
        this.context = context;
        this.image = image;
    }

    @Override
    protected void onPreExecute() {

    }

    protected void onPostExecute(Bitmap bmp) {
        bmp = Bitmap.createScaledBitmap(bmp, 500, 400, true);
        image.setImageBitmap(bmp);
    }

    @Override
    protected Bitmap doInBackground(Object... params) {
        try {
            URL newurl = new URL("http://loyalty.argo.com.br/sites/default/files/All%20Night_0.jpg");
            Bitmap bmp = BitmapFactory.decodeStream(newurl.openConnection().getInputStream());
            return bmp;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
