package loyalty.com.br.loyalty_final_master.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import loyalty.com.br.loyalty_final_master.R;
import loyalty.com.br.loyalty_final_master.Task.UserTask;
import loyalty.com.br.loyalty_final_master.model.UserCashier;

public class LoginActivity extends AppCompatActivity {
    private ImageButton btn_logar;
    private EditText mail;
    private EditText password;
    private UserTask userTask;
    private UserCashier userCashier;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        btn_logar = (ImageButton) findViewById(R.id.btn_logar);
        mail = (EditText) findViewById(R.id.edit_login);
        password = (EditText) findViewById(R.id.edit_password);

        btn_logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userCashier = new UserCashier();
                userCashier.setMail(mail.getText().toString());
                userCashier.setPassword(password.getText().toString());

                userTask = new UserTask(LoginActivity.this, userCashier);
                userTask.execute();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
