package loyalty.com.br.loyalty_final_master.model;


/**
 * Created by root on 07/10/15.
 */

public class UserCashier implements IEntiyBean {

    private Long uid;
    private String name;
    private String mail;
    private String password;
    private Company company;
    private Float cashback;
    private Float resgate;
    private Integer comprasCanceladas;
    private String fileName;

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserCashier userCashier = (UserCashier) o;

        return !(uid != null ? !uid.equals(userCashier.uid) : userCashier.uid != null);
    }

    @Override
    public int hashCode() {
        return uid != null ? uid.hashCode() : 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Float getCashBack() {
        return cashback;
    }

    public void setCashBack(Float cashBack) {
        this.cashback = cashBack;
    }

    public Float getResgate() {
        return resgate;
    }

    public void setResgate(Float resgate) {
        this.resgate = resgate;
    }

    public Integer getComprasCanceladas() {
        return comprasCanceladas;
    }

    public void setComprasCanceladas(Integer comprasCanceladas) {
        this.comprasCanceladas = comprasCanceladas;
    }

    public Float getCashback() {
        return cashback;
    }

    public void setCashback(Float cashback) {
        this.cashback = cashback;
    }
    
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
