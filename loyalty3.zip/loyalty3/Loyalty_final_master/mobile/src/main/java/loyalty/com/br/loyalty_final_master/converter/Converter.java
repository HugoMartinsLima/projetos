package loyalty.com.br.loyalty_final_master.converter;

import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import loyalty.com.br.loyalty_final_master.model.Company;
import loyalty.com.br.loyalty_final_master.model.UserCashier;
import loyalty.com.br.loyalty_final_master.model.UserClient;

/**
 * Created by root on 08/10/15.
 */
public class Converter {

    private Gson gson;

    public Converter() {
        this.gson = new Gson();
    }

    public Object converterTOJSON(String jsonString, Object t) {
        t = gson.fromJson(jsonString, t.getClass());
        return t;
    }

    public UserCashier convertTOJSONCustom(String jsonString) throws JSONException {
        UserCashier userCashier = new UserCashier();
        Company company = new Company();
        userCashier = (UserCashier) converterTOJSON(jsonString, userCashier);

        JSONObject jsonObject = new JSONObject(jsonString);
        JSONObject jsonFieldLogoUser = jsonObject.getJSONObject("field_logo_user");
        String stringCompany = jsonObject.getString("field_parent");

        company = (Company) converterTOJSON(stringCompany, company);

        userCashier.setFileName(jsonFieldLogoUser.get("filename").toString());
        userCashier.setCompany(company);
        return userCashier;
    }

    public List<UserClient> listUserClient(String json) throws JSONException {
        UserClient userClient;
        List<UserClient> userClients = new ArrayList<>();

        JSONObject jsonObject = new JSONObject(json);
        Iterator<String> iter = jsonObject.keys();
        while (iter.hasNext()) {
            userClient = new UserClient();
            String key = iter.next();

            JSONObject userJsonObject = jsonObject.getJSONObject(key);
            userClient = (UserClient) converterTOJSON(userJsonObject.toString(), userClient);
            JSONObject fieldProfissao =  userJsonObject.getJSONObject("field_profiss_o");
            userClient.setProfessional(fieldProfissao.getString("name"));
            userClient.setFileName("images.jpg");
            userClients.add(userClient);
        }
        return userClients;
    }

    public String converterTOObject(Object o) {
        return gson.toJson(o);
    }

}

