package loyalty.com.br.loyalty_final_master.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import loyalty.com.br.loyalty_final_master.R;

public class BuyListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telaoito);
    }

}
