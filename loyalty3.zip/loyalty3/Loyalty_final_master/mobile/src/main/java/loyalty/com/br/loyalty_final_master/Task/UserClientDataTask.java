package loyalty.com.br.loyalty_final_master.Task;

import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

import loyalty.com.br.loyalty_final_master.model.UserClient;

/**
 * Created by hugo on 2/20/16.
 */
public class UserClientDataTask extends AsyncTask<Object, Object, List<UserClient>> {

    private Context context;
    private UserClient userClient;

    public UserClientDataTask(Context context, UserClient userClient) {
        this.context = context;
        this.userClient = userClient;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(List<UserClient> userClients) {
        super.onPostExecute(userClients);
    }

    @Override
    protected List<UserClient> doInBackground(Object... params) {


        return null;
    }
}