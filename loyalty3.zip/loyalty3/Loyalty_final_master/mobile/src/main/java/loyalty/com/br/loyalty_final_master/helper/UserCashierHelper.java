package loyalty.com.br.loyalty_final_master.helper;

import android.app.Activity;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;

import loyalty.com.br.loyalty_final_master.activity.CashierActivity;
import loyalty.com.br.loyalty_final_master.Utils.Constants;
import loyalty.com.br.loyalty_final_master.model.UserCashier;
import loyalty.com.br.loyalty_final_master.R;

/**
 * Created by hugo on 2/2/16.
 */
public class UserCashierHelper {
    private TextView nameCompany;
    private TextView nameCashier;
    private TextView approvedBuy;
    private TextView cancelBuy;
    private TextView waitingBuy;
    private ImageView photoCashier;
    private ImageButton button_client;
    private ImageButton button_buy;
    private ImageButton button_benefit;
    private ImageButton button_message;
    private ImageButton button_logout;
    private Activity activity;
    private UserCashier userCashier;

    public UserCashierHelper(CashierActivity activity) {
        this.activity = activity;
        this.nameCompany = (TextView) activity.findViewById(R.id.titulo_teladois);
        this.nameCashier = (TextView) activity.findViewById(R.id.nome_usuario_teladois);
        this.approvedBuy = (TextView) activity.findViewById(R.id.approved_buy);
        this.cancelBuy = (TextView) activity.findViewById(R.id.cancel_buy);
        this.waitingBuy = (TextView) activity.findViewById(R.id.waiting_buy);
        this.photoCashier = (ImageView) activity.findViewById(R.id.foto_teladois);
        this.button_client = (ImageButton) activity.findViewById(R.id.botao_cliente);
        this.button_buy = (ImageButton) activity.findViewById(R.id.botao_compra);
        this.button_message = (ImageButton) activity.findViewById(R.id.botao_mensagem);
        this.button_benefit = (ImageButton) activity.findViewById(R.id.botao_beneficio);
        this.button_logout = (ImageButton) activity.findViewById(R.id.botao_logout_tela_dois);
    }

    public void setDataForm(UserCashier cashier) {
        nameCompany.setText(cashier.getCompany().getName());
        nameCashier.setText(cashier.getName());
        Glide.with(activity).load(Constants.URI_IMAGE + cashier.getFileName()).override(290, 190).into(photoCashier);
    }


    public TextView getNameCompany() {
        return nameCompany;
    }

    public TextView getNameCashier() {
        return nameCashier;
    }

    public TextView getApprovedBuy() {
        return approvedBuy;
    }

    public TextView getCancelBuy() {
        return cancelBuy;
    }

    public TextView getWaitingBuy() {
        return waitingBuy;
    }

    public Activity getActivity() {
        return activity;
    }

    public ImageView getPhotoCashier() {
        return photoCashier;
    }

    public ImageButton getButton_client() {
        return button_client;
    }

    public ImageButton getButton_buy() {
        return button_buy;
    }

    public ImageButton getButton_benefit() {
        return button_benefit;
    }

    public ImageButton getButton_message() {
        return button_message;
    }

    public UserCashier getUserCashier() {
        return userCashier;
    }

    public ImageButton getButton_logout() {
        return button_logout;
    }
}
