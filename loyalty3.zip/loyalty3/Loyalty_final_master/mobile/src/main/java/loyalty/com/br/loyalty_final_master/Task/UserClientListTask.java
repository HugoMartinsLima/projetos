package loyalty.com.br.loyalty_final_master.Task;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

import loyalty.com.br.loyalty_final_master.converter.Converter;
import loyalty.com.br.loyalty_final_master.helper.UserClientHelper;
import loyalty.com.br.loyalty_final_master.integration.WebClient;
import loyalty.com.br.loyalty_final_master.model.Company;
import loyalty.com.br.loyalty_final_master.model.UserClient;

/**
 * Created by hugo on 2/3/16.
 */
public class UserClientListTask extends AsyncTask<Object, Object, List<UserClient>> {
    private Context context;
    private ProgressDialog progress;
    private Company company;

    public UserClientListTask(Context context, Company company) {
        this.context = context;
        this.company = company;
    }

    @Override
    protected void onPreExecute() {
        progress = ProgressDialog.show(context, "Aguarde...", "Enviando dados para o servidor web", true, true);
    }

    protected void onPostExecute(List<UserClient> userClients) {
        UserClientHelper userClientHelper = new UserClientHelper((Activity) context);
        userClientHelper.loadList(userClients);
        progress.dismiss();
    }

    @Override
    protected List<UserClient> doInBackground(Object... params) {
        try {
            Converter converter = new Converter();
            WebClient webClient = new WebClient("get/clients/company/" + company.getUid());
            List<UserClient> userClients = new ArrayList<>();

            String reply = webClient.post("");
            userClients = converter.listUserClient(reply);
            return userClients;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
