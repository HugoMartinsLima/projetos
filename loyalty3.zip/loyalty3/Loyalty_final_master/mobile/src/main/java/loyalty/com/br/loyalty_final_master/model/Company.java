package loyalty.com.br.loyalty_final_master.model;

/**
 * Created by hugo on 23/11/15.
 */
public class Company implements IEntiyBean {
    private Long uid;
    private String name;
    private String mail;


    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
}
