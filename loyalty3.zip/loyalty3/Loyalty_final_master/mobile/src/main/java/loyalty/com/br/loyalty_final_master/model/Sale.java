package loyalty.com.br.loyalty_final_master.model;

/**
 * Created by hugo on 2/17/16.
 */
public class Sale implements IEntiyBean {
    private Long id;
    private UserClient userClient;
    private UserCashier userCashier;
    private Float cashAmount = (float) 0;
    private Float bonusAmount = (float) 0;
    private Long promoCode;
    private String status;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(Long promoCode) {
        this.promoCode = promoCode;
    }

    public Float getBonusAmount() {
        return bonusAmount;
    }

    public void setBonusAmount(Float bonusAmount) {
        this.bonusAmount = bonusAmount;
    }

    public UserClient getUserClient() {
        return userClient;
    }

    public void setUserClient(UserClient userClient) {
        this.userClient = userClient;
    }

    public Float getCashAmount() {
        return cashAmount;
    }

    public void setCashAmount(Float cashAmount) {
        this.cashAmount = cashAmount;
    }

    public UserCashier getUserCashier() {
        return userCashier;
    }

    public void setUserCashier(UserCashier userCashier) {
        this.userCashier = userCashier;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
