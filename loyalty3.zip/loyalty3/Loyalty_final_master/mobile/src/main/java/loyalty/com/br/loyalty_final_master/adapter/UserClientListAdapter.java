package loyalty.com.br.loyalty_final_master.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import loyalty.com.br.loyalty_final_master.activity.UserClientListActivity;
import loyalty.com.br.loyalty_final_master.R;
import loyalty.com.br.loyalty_final_master.Utils.Constants;
import loyalty.com.br.loyalty_final_master.model.UserClient;

/**
 * Created by hugo on 2/3/16.
 */
public class UserClientListAdapter extends BaseAdapter {

    private final List<UserClient> listUserClients;
    private final UserClientListActivity activity;

    public UserClientListAdapter(UserClientListActivity activity, List<UserClient> listUserClients) {
        this.listUserClients = listUserClients;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return listUserClients.size();
    }

    @Override
    public Object getItem(int position) {
        return listUserClients.get(position);
    }

    @Override
    public long getItemId(int position) {
        return listUserClients.get(position).getUid();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = (View) activity.getLayoutInflater().inflate(R.layout.itemuserclientlist, null);
        UserClient userClient = new UserClient();
        userClient = listUserClients.get(position);

        TextView nameClient = (TextView) view.findViewById(R.id.nome_cliente);
        TextView professional = (TextView) view.findViewById(R.id.nome_profissao_cliente);
        ImageView photoClient = (ImageView) view.findViewById(R.id.fotos_clientes);


        nameClient.setText(userClient.getName());
        professional.setText(userClient.getProfessional());
        Glide.with(view.getContext()).load(Constants.URI_IMAGE + userClient.getFileName()).override(100, 50).into(photoClient);


        return view;
    }
}
