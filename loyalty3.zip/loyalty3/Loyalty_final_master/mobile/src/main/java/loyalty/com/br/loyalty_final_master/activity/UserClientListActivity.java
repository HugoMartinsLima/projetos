package loyalty.com.br.loyalty_final_master.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import loyalty.com.br.loyalty_final_master.Task.UserClientListTask;
import loyalty.com.br.loyalty_final_master.model.UserCashier;
import loyalty.com.br.loyalty_final_master.R;

public class UserClientListActivity extends AppCompatActivity {

    UserCashier userCashier = new UserCashier();
    ImageButton buttonAddUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telatres);
        userCashier = (UserCashier) getIntent().getSerializableExtra("USER_CASHIER_LOGADO");
        buttonAddUser = (ImageButton) findViewById(R.id.botao_add_usuario);
        buttonAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserClientListActivity.this, UserClientDataActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        UserClientListTask userClientListTask = new UserClientListTask(UserClientListActivity.this, userCashier.getCompany());
        userClientListTask.execute();
    }
}