package loyalty.com.br.loyalty_final_master.helper;

import android.widget.EditText;

import loyalty.com.br.loyalty_final_master.activity.SalesDataActivity;
import loyalty.com.br.loyalty_final_master.model.Sale;
import loyalty.com.br.loyalty_final_master.R;
import loyalty.com.br.loyalty_final_master.model.UserClient;

/**
 * Created by hugo on 2/17/16.
 */
public class SalesHelper {

    private EditText afiliado2;
    private EditText valor;
    private EditText resgate_cashback;
    private EditText codigo_oferta;
    private Sale sale;

    public SalesHelper(SalesDataActivity salesDataActivity) {
        afiliado2 = (EditText) salesDataActivity.findViewById(R.id.afiliado2);
        valor = (EditText) salesDataActivity.findViewById(R.id.cashAmount);
        resgate_cashback = (EditText) salesDataActivity.findViewById(R.id.resgate_cashback);
        codigo_oferta = (EditText) salesDataActivity.findViewById(R.id.codigo_oferta);

        sale = new Sale();
    }

    public SalesHelper() {

    }

    public Sale getSale() {
        UserClient userClient = new UserClient();
        userClient.setUid(Long.parseLong(afiliado2.getText().toString()));

        sale.setUserClient(userClient);
        sale.setCashAmount(Float.parseFloat(valor.getText().toString()));
        sale.setBonusAmount(Float.parseFloat(resgate_cashback.getText().toString()));
        if (codigo_oferta.getText().length() > 0) {
            sale.setPromoCode(Long.parseLong(codigo_oferta.getText().toString()));
        }

        return sale;
    }
}
