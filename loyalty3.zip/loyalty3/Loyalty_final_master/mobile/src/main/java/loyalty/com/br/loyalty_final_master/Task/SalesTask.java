package loyalty.com.br.loyalty_final_master.Task;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

import loyalty.com.br.loyalty_final_master.Utils.Constants;
import loyalty.com.br.loyalty_final_master.integration.WebClient;
import loyalty.com.br.loyalty_final_master.model.Sale;

/**
 * Created by hugo on 2/17/16.
 */

public class SalesTask extends AsyncTask<Object, Object, Sale> {
    private Context context;
    private ProgressDialog progress;
    private Sale sale;

    public SalesTask(Context context, Sale sale) {
        this.context = context;
        this.sale = sale;
    }

    @Override
    protected void onPreExecute() {
        progress = ProgressDialog.show(context, "Aguarde...", "Enviando dados para o servidor web", true, true);
    }

    protected void onPostExecute(Sale sale) {
        progress.dismiss();
    }

    @Override
    protected Sale doInBackground(Object... params) {
        StringBuilder url = new StringBuilder("put/transaction?uid=");
        String promoCode = "";

        url.append(sale.getUserCashier().getUid());
        url.append("&client_id=" + sale.getUserClient().getUid());
        url.append("&cash_amount=" + sale.getCashAmount());
        url.append("&bonus_amount=" + sale.getBonusAmount());

        if (sale.getPromoCode() != null) {
            promoCode = sale.getPromoCode().toString();
        }
        url.append("&promo_code=" + promoCode);

        WebClient web = new WebClient(url.toString());
        sale.setStatus(web.post(""));
        return sale;
    }
}
