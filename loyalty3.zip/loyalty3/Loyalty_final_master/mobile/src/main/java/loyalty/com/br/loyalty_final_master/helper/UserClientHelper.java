package loyalty.com.br.loyalty_final_master.helper;

import android.app.Activity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import loyalty.com.br.loyalty_final_master.activity.UserClientListActivity;
import loyalty.com.br.loyalty_final_master.R;

import loyalty.com.br.loyalty_final_master.adapter.UserClientListAdapter;
import loyalty.com.br.loyalty_final_master.model.UserClient;

/**
 * Created by hugo on 2/3/16.
 */
public class UserClientHelper {

    private ImageView photoClient;
    private TextView nameClient;
    private TextView professional;
    private Activity activity;
    private ListView listViewUserClient;

    private EditText edName;
    private EditText edCPF;
    private EditText edMail;
    private EditText edFone;
    private EditText edPassword;
    private EditText edConfirmPassword;

    private UserClient client;


    public UserClientHelper(Activity activity) {
        this.activity = activity;
        this.nameClient = (TextView) activity.findViewById(R.id.nome_cliente);
        this.professional = (TextView) activity.findViewById(R.id.nome_profissao_cliente);
        this.photoClient = (ImageView) activity.findViewById(R.id.fotos_clientes);
        this.listViewUserClient = (ListView) activity.findViewById(R.id.listViewUserClient);

    }


    public UserClientHelper(Activity activity, String function) {
        this.activity = activity;
        edName = (EditText) activity.findViewById(R.id.edName);
        edCPF = (EditText) activity.findViewById(R.id.edCPF);
        edMail = (EditText) activity.findViewById(R.id.edEmail);
        edFone = (EditText) activity.findViewById(R.id.edFone);
        edPassword = (EditText) activity.findViewById(R.id.edPassword);
        edConfirmPassword = (EditText) activity.findViewById(R.id.edConfirmSenha);
        client = new UserClient();

    }

    public UserClient getUserClient() {
        client.setName(edName.getText().toString());
        client.setCPF(edCPF.getText().toString());
        client.setFone(edFone.getText().toString());
        client.setMail(edMail.getText().toString());
        client.setPassword(edPassword.getText().toString());

        return client;
    }

    public void loadList(List<UserClient> userClientList) {
        activity.registerForContextMenu(listViewUserClient);
        UserClientListActivity activityUserClient = (UserClientListActivity) activity;
        UserClientListAdapter adapter = new UserClientListAdapter(activityUserClient, userClientList);
        listViewUserClient.setAdapter(adapter);
    }


    public ImageView getPhotoClient() {
        return photoClient;
    }

    public Activity getActivity() {
        return activity;
    }

    public TextView getProfessional() {
        return professional;
    }

    public TextView getNameClient() {
        return nameClient;
    }
}
