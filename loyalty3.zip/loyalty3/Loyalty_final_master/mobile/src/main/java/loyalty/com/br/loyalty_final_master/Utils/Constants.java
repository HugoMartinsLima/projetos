package loyalty.com.br.loyalty_final_master.Utils;


/**
 * Created by hugo on 2/1/16.
 */
public class Constants {
    public static String URI = "http://loyalty.argo.com.br/";
    public static String URL = URI + "loyalty/api/";
    public static String URI_IMAGE = URI + "sites/default/files/";
}
