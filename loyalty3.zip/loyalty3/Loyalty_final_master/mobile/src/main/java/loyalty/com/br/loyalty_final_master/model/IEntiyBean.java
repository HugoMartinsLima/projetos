package loyalty.com.br.loyalty_final_master.model;

import java.io.Serializable;

/**
 * Created by root on 07/10/15.
 */
public interface IEntiyBean extends Serializable {

}
