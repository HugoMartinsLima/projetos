package loyalty.com.br.loyalty_final_master.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import loyalty.com.br.loyalty_final_master.R;
import loyalty.com.br.loyalty_final_master.Task.SalesTask;
import loyalty.com.br.loyalty_final_master.helper.SalesHelper;
import loyalty.com.br.loyalty_final_master.model.Sale;
import loyalty.com.br.loyalty_final_master.model.UserCashier;

public class SalesDataActivity extends AppCompatActivity {
    ImageView buttonOK;
    UserCashier userCashier;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales);

        userCashier = (UserCashier) getIntent().getSerializableExtra("USER_CASHIER_LOGADO");

        buttonOK = (ImageView) findViewById(R.id.botao_ok_cashback);

        buttonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SalesHelper salesHelper = new SalesHelper(SalesDataActivity.this);
                Sale sale = salesHelper.getSale();
                sale.setUserCashier(userCashier);
                SalesTask salesTask = new SalesTask(SalesDataActivity.this, sale);
                salesTask.execute();

            }
        });
    }
}
