package loyalty.com.br.loyalty_final_master.Task;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import loyalty.com.br.loyalty_final_master.activity.CashierActivity;
import loyalty.com.br.loyalty_final_master.converter.Converter;
import loyalty.com.br.loyalty_final_master.integration.WebClient;
import loyalty.com.br.loyalty_final_master.model.UserCashier;

/**
 * Created by root on 08/10/15.
 */

public class UserTask extends AsyncTask<Object, Object, UserCashier> {
    private Context context;
    private ProgressDialog progress;
    private UserCashier userCashierReceived;

    public UserTask(Context context, UserCashier userCashierReceived) {
        this.context = context;
        this.userCashierReceived = userCashierReceived;
    }

    @Override
    protected void onPreExecute() {
        progress = ProgressDialog.show(context, "Aguarde...", "enviando dados para o servidor web", true, true);
    }

    protected void onPostExecute(UserCashier userCashier) {
        //if (userCashier.getUid() != null) {
            Activity activity = (Activity) context;
            Intent intent = new Intent(activity, CashierActivity.class);
            intent.putExtra("USER_CASHIER_LOGADO", userCashier);
            activity.startActivity(intent);
            //}
        progress.dismiss();
    }

    @Override
    protected UserCashier doInBackground(Object... params) {
        try {
            WebClient webClient = new WebClient("do_auth?mail=" + userCashierReceived.getMail() + "&password=" + userCashierReceived.getPassword());
            Converter converter = new Converter();

            String param = converter.converterTOObject(userCashierReceived);
            String retorno = webClient.post(param);

            UserCashier userCashier = converter.convertTOJSONCustom(retorno);
            return userCashier;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
