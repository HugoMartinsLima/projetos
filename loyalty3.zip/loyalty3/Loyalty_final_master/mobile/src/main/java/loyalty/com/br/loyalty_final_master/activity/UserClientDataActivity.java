package loyalty.com.br.loyalty_final_master.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import loyalty.com.br.loyalty_final_master.R;
import loyalty.com.br.loyalty_final_master.Task.UserClientListTask;
import loyalty.com.br.loyalty_final_master.helper.UserClientHelper;
import loyalty.com.br.loyalty_final_master.model.Company;
import loyalty.com.br.loyalty_final_master.model.UserClient;

/**
 * Created by hugo on 2/13/16.
 */
public class UserClientDataActivity extends AppCompatActivity {

    ImageView saveUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telaquatro);
        saveUser = (ImageView) findViewById(R.id.save_user);

        saveUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserClientHelper helper = new UserClientHelper(UserClientDataActivity.this, "");
                UserClient userClient = helper.getUserClient();

            }
        });
    }

}